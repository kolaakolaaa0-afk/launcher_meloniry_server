float4	tempF1; 
float4	tempF2; 
float4	tempF3; 
float4	Timer;
float4	ScreenSize;
float	ENightDayFactor;
float	EInteriorFactor;
float4	WeatherAndTime;
float	EAdaptiveQualityFactor;
float	EBloomAmount;
float	FieldOfView;
float	GameTime;
float4	SunDirection; 
float4	CustomShaderConstants1[8];
texture2D texs0;
texture2D texs3;
texture2D texs4;
texture2D texs7;
texture2D texNormal;
texture2D texDepth;
sampler2D _s0 = sampler_state
{
	Texture   = <texs0>;
	MinFilter = POINT;
	MagFilter = POINT;
	MipFilter = NONE;
	AddressU  = Clamp;
	AddressV  = Clamp;
	SRGBTexture=FALSE;
	MaxMipLevel=0;
	MipMapLodBias=0;
};
sampler2D _s3 = sampler_state
{
	Texture   = <texs3>;
	MinFilter = LINEAR;
	MagFilter = LINEAR;
	MipFilter = NONE;
	AddressU  = Clamp;
	AddressV  = Clamp;
	SRGBTexture=FALSE;
	MaxMipLevel=0;
	MipMapLodBias=0;
};
sampler2D _s4 = sampler_state
{
	Texture   = <texs4>;
	MinFilter = LINEAR;
	MagFilter = LINEAR;
	MipFilter = NONE;
	AddressU  = Clamp;
	AddressV  = Clamp;
	SRGBTexture=FALSE;
	MaxMipLevel=0;
	MipMapLodBias=0;
};
sampler2D _s7 = sampler_state
{
	Texture   = <texs7>;
	MinFilter = LINEAR;
	MagFilter = LINEAR;
	MipFilter = NONE;
	AddressU  = Clamp;
	AddressV  = Clamp;
	SRGBTexture=FALSE;
	MaxMipLevel=0;
	MipMapLodBias=0;
};
sampler2D SamplerNormal = sampler_state
{
	Texture   = <texNormal>;
	MinFilter = POINT;
	MagFilter = POINT;
	MipFilter = NONE;
	AddressU  = Clamp;
	AddressV  = Clamp;
	SRGBTexture=FALSE;
	MaxMipLevel=0;
	MipMapLodBias=0;
};
sampler2D SamplerDepth = sampler_state
{
	Texture   = <texDepth>;
	MinFilter = POINT;
	MagFilter = POINT;
	MipFilter = NONE;
	AddressU  = Clamp;
	AddressV  = Clamp;
	SRGBTexture=FALSE;
	MaxMipLevel=0;
	MipMapLodBias=0;
};
texture2D texNoise < string ResourceName="BlueNoise.png"; >;
sampler2D SamplerNoise = sampler_state
{
	Texture   = <texNoise>;
	MinFilter = POINT;
	MagFilter = POINT;
	MipFilter = NONE;
	AddressU  = Wrap;
	AddressV  = Wrap;
	SRGBTexture=FALSE;
	MaxMipLevel=0;
	MipMapLodBias=0;
};
struct VS_OUTPUT_POST
{
	float4 vpos  : POSITION;
	float2 txcoord0 : TEXCOORD0;
};
struct VS_INPUT_POST
{
	float3 pos  : POSITION;
	float2 txcoord0 : TEXCOORD0;
};
VS_OUTPUT_POST VS_PostProcess(VS_INPUT_POST IN)
{
	VS_OUTPUT_POST OUT;
	OUT.vpos=float4(IN.pos.x,IN.pos.y,IN.pos.z,1.0);
	OUT.txcoord0.xy=IN.txcoord0.xy;
	return OUT;
}
float4 PS_PostProcess(VS_OUTPUT_POST IN, float2 vPos : VPOS) : COLOR
{
	float4 color = tex2D(_s0, IN.txcoord0.xy);
	float4 xcolorbloom = tex2D(_s3, IN.txcoord0.xy);
	xcolorbloom.xyz=xcolorbloom-color;
	xcolorbloom.xyz=max(xcolorbloom, 0.0);
	color.xyz+=xcolorbloom*EBloomAmount;
    float pos = frac(vPos.xy/2.0) + 0.25;
    float3 sh = float3(0.25,-0.25,0.25) * (1.0 / (exp2(8.0) - 1.0));
     	   sh = lerp(2.0 * sh, -2.0 * sh, pos);
	float2 j = frac(vPos.xy*0.0625)+0.03125;
	float4 n = tex2D(SamplerNoise, j);
	const float	da = 0.008;
	       color.rgb+= sh;	
	       color.rgb+=(-n.x*da) + (da*0.5);				   
	return color;
}
technique PostProcess
{
pass P0
	{
		VertexShader = compile vs_3_0 VS_PostProcess();
		PixelShader  = compile ps_3_0 PS_PostProcess();
	}
}