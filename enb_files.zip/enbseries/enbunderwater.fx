bool	ECausticsEnable
<
	string UIName="Underwater: EnableCaustics";
> = {true};
float	ECausticsIntensity
<
	string UIName="Underwater: CausticsIntensity";
	string UIWidget="Spinner";
	float UIMin=0.0;
	float UIMax=10.0;
> = {4.0};
float4	tempF1; 
float4	tempF2; 
float4	tempF3; 
float4	ScreenSize;
float	ENightDayFactor;
float	EInteriorFactor;
float4	WeatherAndTime;
float4	Timer;
float	FieldOfView;
float	GameTime;
float4	SunDirection; 
float4	CustomShaderConstants1[8];
float4	MatrixVP[4];
float4	MatrixInverseVP[4];
float4	MatrixVPRotation[4];
float4	MatrixInverseVPRotation[4];
float4	MatrixView[4];
float4	MatrixInverseView[4];
float4	CameraPosition;
float4x4	MatrixWVP;
float4x4	MatrixWVPInverse;
float4x4	MatrixWorld;
float4x4	MatrixProj;
float4	FogParam; 
float4	FogFarColor;
float4	WaterParameters1; 
texture2D texColor; 
texture2D texDepth;
texture2D texNormal;
texture2D texEnv; 
texture2D texNoise; 
sampler2D SamplerColor = sampler_state
{
    Texture   = <texColor>;
    MinFilter = LINEAR;
    MagFilter = LINEAR;
    MipFilter = NONE;
	AddressU  = Clamp;
	AddressV  = Clamp;
	SRGBTexture=FALSE;
	MaxMipLevel=0;
	MipMapLodBias=0;
};
sampler2D SamplerDepth = sampler_state
{
    Texture   = <texDepth>;
    MinFilter = LINEAR;
    MagFilter = LINEAR;
    MipFilter = NONE;
	AddressU  = Clamp;
	AddressV  = Clamp;
	SRGBTexture=FALSE;
	MaxMipLevel=0;
	MipMapLodBias=0;
};
sampler2D SamplerNormal = sampler_state
{
    Texture   = <texNormal>;
    MinFilter = LINEAR;
    MagFilter = LINEAR;
    MipFilter = NONE;
	AddressU  = Clamp;
	AddressV  = Clamp;
	SRGBTexture=FALSE;
	MaxMipLevel=0;
	MipMapLodBias=0;
};
sampler2D SamplerEnv = sampler_state
{
    Texture   = <texEnv>;
    MinFilter = LINEAR;
    MagFilter = LINEAR;
	MipFilter = LINEAR;
	AddressU  = Clamp;
	AddressV  = Clamp;
	SRGBTexture=FALSE;
	MaxMipLevel=0;
	MipMapLodBias=0;
};
sampler2D SamplerNoise = sampler_state
{
	Texture   = <texNoise>;
	MinFilter = POINT;
	MagFilter = POINT;
	MipFilter = NONE;
	AddressU  = Wrap;
	AddressV  = Wrap;
	SRGBTexture=FALSE;
	MaxMipLevel=0;
	MipMapLodBias=0;
};
struct VS_INPUT
{
	float3	pos : POSITION;
	float2	txcoord0 : TEXCOORD0;
};
struct VS_OUTPUT
{
	float4	pos : POSITION;
	float2	txcoord0 : TEXCOORD0;
};
VS_OUTPUT	VS_Draw(VS_INPUT IN)
{
    VS_OUTPUT OUT;
	float4	pos=float4(IN.pos.x,IN.pos.y,IN.pos.z,1.0);
	OUT.pos=pos;
	OUT.txcoord0=IN.txcoord0;
    return OUT;
}
float3	hash1(float3 p3)
{
	p3 = frac(p3 * float3(0.1031, 0.11369, 0.13787));
	p3 += dot(p3, p3.yxz+19.19);
	p3=float3((p3.x+p3.y), (p3.x+p3.z), (p3.y+p3.z)) * p3.zyx;
	return frac(p3);
}
float	WorleyNoise(float3 n, float scale)
{
	n *= scale;
	float2	dis=1.0;
	for (float x=-1.0; x<1.01; x+=1.0)
	{
		for (float y=-1.0; y<1.01; y+=1.0)
		{
			for (float z=-1.0; z<1.01; z+=1.0)
			{
				float3	xyz=float3(x,y,z);
				float3	frcn=frac(n);
				float3	p=n-frcn + xyz; 
				float3	pp = p;
				if (pp.z < 0.0) pp.z = scale + pp.z;
				if (pp.z > 1.0) pp.z = pp.z - scale;
				float2	sqrdist;
				frcn=xyz - frcn;
				p = hash1(pp) + frcn;
				sqrdist.x=dot(p, p);
				pp.z+=0.012;
				p = hash1(pp) + frcn;
				sqrdist.y=dot(p, p);
				dis.xy = min(dis.xy, sqrdist.xy);
			}
		}
	}
	dis.x=dis.x*dis.y;
	return saturate(sqrt(dis.x));
}
float4	PS_Draw(VS_OUTPUT IN, float2 vPos : VPOS) : COLOR
{
	float4	res;
	float4	color;
	float2	coord;
	coord.xy=IN.txcoord0;
	float	scenedepth=tex2D(SamplerDepth, IN.txcoord0.xy).x;
	float4 tempvec;
	float4 worldpos;
	float4 normalpos;
	tempvec.xy=IN.txcoord0.xy*2.0-1.0;
	tempvec.y=-tempvec.y;
	tempvec.z=scenedepth;
	tempvec.w=1.0;
	worldpos.x=dot(tempvec, MatrixInverseVPRotation[0]);
	worldpos.y=dot(tempvec, MatrixInverseVPRotation[1]);
	worldpos.z=dot(tempvec, MatrixInverseVPRotation[2]);
	worldpos.w=dot(tempvec, MatrixInverseVPRotation[3]);
	worldpos.xyz/=worldpos.w;
	worldpos.xyz+=CameraPosition;
	float	deepfade=max(WaterParameters1.w+CameraPosition.z-worldpos.z, 0.0);
	deepfade*=0.1; 
	deepfade=deepfade/(deepfade+1.0);
	tempvec.xyz=worldpos-CameraPosition;
	float	distfact=dot(tempvec.xyz,tempvec.xyz);
	distfact=saturate(1.0-distfact*0.000025);
	float	scale=8.0;
	float3	causticspos=worldpos;
	causticspos*=0.25;
	causticspos.z*=0.25;
	causticspos.z+=Timer.x*1677.7216 * 2.0; 
	causticspos.z=frac(causticspos.z);
	float	caustic=0.0;
	float	usecaustic=0.0;
	if (ECausticsEnable==true) usecaustic=1.0;
	usecaustic*=distfact;
	usecaustic*=0.9-deepfade;
	if (usecaustic>=0.1)
	{
		caustic=WorleyNoise(causticspos.xyz, scale);
	}
	caustic=caustic*caustic; 
	caustic*=lerp(1.0, caustic, deepfade);
	caustic=caustic-0.1;
	caustic*=1.0-deepfade;
	caustic*=saturate((WaterParameters1.w+CameraPosition.z - worldpos.z));
	caustic*=distfact;
	caustic*=ECausticsIntensity;
	float3	normal=tex2D(SamplerNormal, IN.txcoord0.xy)*2.0-1.0;
	tempvec.xy=normal.xy;
	tempvec.x=-tempvec.x;
	tempvec.z=normal.z;
	normalpos.x=dot(tempvec.xyz, MatrixInverseView[0]);
	normalpos.y=dot(tempvec.xyz, MatrixInverseView[1]);
	normalpos.z=dot(tempvec.xyz, MatrixInverseView[2]);
	normalpos.z=-normalpos.z;
	normal.xyz=normalize(normalpos.xyz);
	caustic*=saturate(normal.z*0.5+0.5);
	color=tex2D(SamplerColor, IN.txcoord0.xy);
	res.xyz=(1.0+caustic) * (1.0-deepfade) * color;
	float	deepness=max(WaterParameters1.w, 0.0);
	deepness*=0.1;
	deepness=deepness/(deepness+1.0);
	res.xyz*=1.0-deepness*0.7; 
    float dfog = pow(tex2D(SamplerDepth, coord).x, 11.0);	
    res.xyz = lerp(res, dfog*float3(0.4, 0.8, 0.7)*0.4, 0.95);
	res.w=color.w;
	return res;
}
technique Draw
{
    pass p0
    {
	VertexShader = compile vs_3_0 VS_Draw();
	PixelShader  = compile ps_3_0 PS_Draw();
	}
}