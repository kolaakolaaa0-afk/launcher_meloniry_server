float4	tempF1; 
float4	tempF2; 
float4	tempF3; 
float4	ScreenSize;
float	ENightDayFactor;
float	EInteriorFactor;
float4	WeatherAndTime;
float4	Timer;
float	FieldOfView;
float	GameTime;
float4	SunDirection; 
float4	CustomShaderConstants1[8];
float4	MatrixVP[4];
float4	MatrixInverseVP[4];
float4	MatrixVPRotation[4];
float4	MatrixInverseVPRotation[4];
float4	MatrixView[4];
float4	MatrixInverseView[4];
float4	CameraPosition;
float4x4	MatrixWVP;
float4x4	MatrixWVPInverse;
float4x4	MatrixWorld;
float4x4	MatrixProj;
float4	FogParam; 
float4	FogFarColor;
texture2D texNoise; 
sampler2D SamplerNoise = sampler_state
{
	Texture   = <texNoise>;
	MinFilter = POINT;
	MagFilter = POINT;
	MipFilter = NONE;
	AddressU  = Wrap;
	AddressV  = Wrap;
	SRGBTexture=FALSE;
	MaxMipLevel=0;
	MipMapLodBias=0;
};
struct VS_INPUT
{
	float3	pos : POSITION;
	float2	txcoord0 : TEXCOORD0;
};
struct VS_OUTPUT
{
	float4	pos : POSITION;
	float2	txcoord0 : TEXCOORD0;
};
VS_OUTPUT	VS_Draw(VS_INPUT IN)
{
    VS_OUTPUT OUT;
	float4	pos=float4(IN.pos.x,IN.pos.y,IN.pos.z,1.0);
	OUT.pos=pos;
	OUT.txcoord0=IN.txcoord0;
    return OUT;
}
#include "AmbientLight.fx"
float4	PS_Draw(VS_OUTPUT IN, float2 vPos : VPOS) : COLOR
{
	float4 res = 1.0;
	float2 texcoord = IN.txcoord0.xy;
	float theta = texcoord.y * 3.1415926536;
	float phi = texcoord.x * 6.2831853071;
	float3 camdirection = float3(sin(theta)*cos(phi), sin(theta)*sin(phi), cos(theta));
	       camdirection = normalize(camdirection);
	float3 camdirfixed = camdirection;
	       camdirfixed.z = max(camdirection.z,0.0);
	       camdirfixed = normalize(camdirfixed.xyz);
	res.xyz = GetAtmosphericScattering2(camdirfixed.xyz, SunDirection.xyz, GameTime, 1.0, 0.25, 4.0, 1.3, 0.9, 0.5);
	float sa = WeatherSetts(0.25, 0.95);
	res.xyz *= lerp(1.0, smoothstep(-0.53, 0.05,camdirection.z), sa);
	res.w = 1.0;
	return res;
}
technique Draw
{
    pass p0
    {
	VertexShader = compile vs_3_0 VS_Draw();
	PixelShader  = compile ps_3_0 PS_Draw();
	}
}