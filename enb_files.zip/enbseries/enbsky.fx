float4	tempF1; 
float4	tempF2; 
float4	tempF3; 
float4	ScreenSize;
float	ENightDayFactor;
float	EInteriorFactor;
float4	WeatherAndTime;
float4	Timer;
float	FieldOfView;
float	GameTime;
float4	SunDirection; 
float4	CustomShaderConstants1[8];
float4	MatrixVP[4];
float4	MatrixInverseVP[4];
float4	MatrixVPRotation[4];
float4	MatrixInverseVPRotation[4];
float4	MatrixView[4];
float4	MatrixInverseView[4];
float4	CameraPosition;
float4x4	MatrixWVP;
float4x4	MatrixWVPInverse;
float4x4	MatrixWorld;
float4x4	MatrixProj;
float4	FogParam; 
float4	FogFarColor;
texture2D texNoise; 
sampler2D SamplerNoise = sampler_state
{
	Texture   = <texNoise>;
	MinFilter = POINT;
	MagFilter = POINT;
	MipFilter = NONE;
	AddressU  = Wrap;
	AddressV  = Wrap;
	SRGBTexture=FALSE;
	MaxMipLevel=0;
	MipMapLodBias=0;
};
struct VS_INPUT
{
	float3	pos : POSITION;
	float4	diff : COLOR0;
};
struct VS_OUTPUT
{
	float4	pos : POSITION;
	float4	diff : COLOR0;
	float4	vposition : TEXCOORD6;
};
VS_OUTPUT	VS_Draw(VS_INPUT IN)
{
    VS_OUTPUT OUT;
	float4	pos=float4(IN.pos.x,IN.pos.y,IN.pos.z,1.0);
	float4	tpos=mul(pos, MatrixWVP);
	OUT.diff=IN.diff;
	OUT.pos=tpos;
	OUT.vposition=tpos;
    return OUT;
}
float4	PS_Draw(VS_OUTPUT IN, float2 vPos : VPOS) : COLOR
{
	float4	res;
	res=IN.diff; 
	float2	jitteruv;
	jitteruv=frac(vPos.xy*0.0625)+0.03125;
	float4	jitter=tex2D(SamplerNoise, jitteruv);
	const float	ditheramount=0.008;
	res.xyz+=(-jitter.x*ditheramount) + (ditheramount*0.5);
	res.xyz=max(res.xyz, 0.0);
	res.w=1.0;
	return res;
}
technique Draw
{
    pass p0
    {
	VertexShader = compile vs_3_0 VS_Draw();
	PixelShader  = compile ps_3_0 PS_Draw();
	AlphaBlendEnable=FALSE; 
	AlphaTestEnable=FALSE;
	}
}